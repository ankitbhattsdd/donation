import React, { Component } from 'react'
import { View, Image, Dimensions, Text, StyleSheet, TextInput, TouchableOpacity } from 'react-native'
// import Icon from 'react-native-vector-icons/MaterialCommunityIcons'
// import MIcon from 'react-native-vector-icons/MaterialIcons'

// import { COLOR } from '../color'

const { height: h, width: w } = Dimensions.get('window');

export default class FloatingLabel extends Component {
    constructor(props) {
        super(props)
        this.state = {
            Focused: false,
            text: '',
            show: false
        }
        this.focusNextField = this.focusNextField.bind(this);
        this.inputs = {};
    }

    focusNextField(id) {
        this.inputs[id].focus();
    }
    onChange(text) {
        this.setState({ text })
        this.props.onChangeText(text)
    }
    render() {
        return (
            <View style={{ borderBottomWidth: 1, borderBottomColor: this.state.Focused ?'brown' : 'grey', marginBottom: this.props.margin }}>
                <Text style={{ fontWeight: '500', fontSize: 14, color: this.state.Focused || this.state.text !== '' ? 'grey' : 'transparent' }}>{this.props.name}</Text>
                <View style={{ flexDirection: 'row' }}>
                    <TextInput
                        style={{ width: this.props.password ? this.props.width - w * .06 : this.props.width, backgroundColor: 'transparent', height: h * .07, fontSize: 18, color:'grey' }}
                        onChangeText={(text) => this.onChange(text)} //this.props.onChangeText(text)
                        underlineColorAndroid='transparent'
                        placeholder={this.state.Focused ? '' : this.props.name}
                        placeholderTextColor={'grey'}
                        onFocus={() => this.setState({ Focused: true })}
                        onEndEditing={() => this.setState({ Focused: false })} //this.setState({Focused: false})
                        value={this.state.text}
                        secureTextEntry={this.props.password && this.state.show === false ? true : false}
                        keyboardType={this.props.email ? 'email-address' : this.props.number ? 'numeric' : 'default'}
                        onSubmitEditing={() => {
                            this.focusNextField('two');
                        }}
                    />
                    {/* {
                        this.props.password ?
                            <TouchableOpacity onPress={() => this.setState({ show: !this.state.show })} style={{ justifyContent: 'center' }}>
                                <Icon name={this.state.show ? 'lock-open' : 'lock'} color={COLOR.GREY} size={w * .06} style={{ backgroundColor: 'transparent' }} />
                            </TouchableOpacity>
                            : this.props.drop ?
                                <TouchableOpacity onPress={() => this.setState({ show: !this.state.show })} style={{ justifyContent: 'center' }}>
                                    <MIcon name='arrow-drop-down' color={COLOR.GREY} size={w * .06} style={{ backgroundColor: 'transparent' }} />
                                </TouchableOpacity>
                                :
                                null
                    } */}
                </View>
            </View>
        )
    }
}