import * as React from 'react';
import { View, TextInput, TouchableOpacity, ScrollView, Image, StyleSheet, Text, Dimensions, Button, ActivityIndicator, AsyncStorage, Platform } from 'react-native';
import { KeyboardAwareScrollView } from "react-native-keyboard-aware-scroll-view";
import { Actions } from "react-native-router-flux";
import FloatingLabel from "react-native-floating-labels";
import Carousel, { Pagination } from 'react-native-snap-carousel';
import { Dropdown } from 'react-native-material-dropdown';
import BTClient from 'react-native-braintree-xplat';
import { SERVER_URL, FONT_SIZE } from "./global";

const WINDOW = Dimensions.get('window');
const LOGO = require("../Images/logo.png");
console.ignoredYellowBox = ['Warning:'];

const imageSwiper = [{
    image: require('../Images/slider-1.png')
},
{
    image: require('../Images/1.jpg')
}, {
    image: require('../Images/2.jpg')
}, {
    image: require('../Images/3.jpg')
},
]

class Address extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            name: '',
            amount: '',
            stateLists: [],
            streetAddress1: '',
            streetAddress1_Clicked: false,
            streetAddress1_Empty: false,

            city: '',
            city_Clicked: false,
            city_Empty: false,

            postalCode: '',
            postalCode_Clicked: false,
            postalCode_Empty: false,

            streetAddress2: false,
            activeSlide: 0,
            toggle: false,
            disable: true
        }
    }

    componentDidMount() {

        // client token api
        clientToken = fetch(SERVER_URL + 'Checkouts/GenerateToken', {
            method: 'GET'
        })
            .then((response) => response.json())
            .then((clientToken) => {
                this.setState({ disable: false })
                BTClient.setup(clientToken.token)
            })

        // get states api
        stateList = fetch(SERVER_URL + 'EmailNotifier/GetStateList', {
            method: 'GET',
        })
            .then((response) => response.json())
            .then((responseJson) => {
                this.setState({ stateLists: responseJson });
            })
    }

    componentWillMount() {

        AsyncStorage.getItem('streetAddress1').then((streetAddress1) => {
            if (streetAddress1) {
                this.setState({ streetAddress1: streetAddress1 })
            }
        });

        AsyncStorage.getItem('streetAddress2').then((streetAddress2) => {
            if (streetAddress2) {
                this.setState({ streetAddress2: streetAddress2 })
            }
        });

        AsyncStorage.getItem('city').then((city) => {
            if (city) {
                this.setState({ city: city })
            }
        });

        AsyncStorage.getItem('states').then((states) => {
            if (states) {
                this.setState({ states: states })
            }
        });

        AsyncStorage.getItem('postalCode').then((postalCode) => {
            if (postalCode) {
                this.setState({ postalCode: postalCode })
            }
        });

    }

    addPayment = (data) => {

        AsyncStorage.setItem('streetAddress1', this.state.streetAddress1);
        AsyncStorage.setItem('streetAddress2', this.state.streetAddress2);
        AsyncStorage.setItem('city', this.state.city);
        AsyncStorage.setItem('states', this.state.states);
        AsyncStorage.setItem('postalCode', this.state.postalCode);

        const card = {
        }
        const options = {
            bgColor: '#FFF',
            tintColor: 'orange',
            callToActionText: 'Donate Now',
            threeDSecure: {
                amount: data.amount
            }
        }

        BTClient.showPaymentViewController(options).then((nonce) => {
            console.log("payment done===>", nonce)

            let dataTosend = {
                "payment_method_nonce": nonce,
                "amount": data.amount,
                "organizationName": "Bridge to Uganda",
                "donorFullName": data.name,
                "donorEmailAddress": data.email,
                "donationAmount": data.amount,
                "donorAmount": data.amount,
                "donorPurpose": data.purpose,
                "donorPostalAddress": this.state.streetAddress1
            }

            //   fetch('http://108.168.203.227/donationapp/api/Checkouts/CreatePayment', {
            fetch(SERVER_URL + 'Checkouts/CreatePaymentWithDetails', {
                method: 'POST',
                headers: {
                    Accept: 'application/json',
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(dataTosend),
            })
                .then((response) => {
                    response.json(), console.log('response-',
                        JSON.stringify(response))
                    if (response.status === 200)
                        Actions.ThankYou({ data })
                    else
                        Actions.Error()
                })
        })
            .catch(function (err) {
                Actions.Error();
                //error handling
                console.log("err===>", err)
            });
    }


    _renderItem({ item, index }) {

        return (
            <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
                <Image source={item.image} resizeMode='contain' style={{ height: WINDOW.height * 0.28, width: WINDOW.width }} />
            </View>
        );
    }

    render() {

        var arr = []
        stateList = this.state.stateLists.map((states) => {
            arr.push({
                id: states.id,
                value: states.name
            })
        })

        let datap = {
            name: this.props.Name,
            amount: this.props.Amount,
            purpose: this.props.Purpose,
            email: this.props.Email
        }

        return (
            <KeyboardAwareScrollView enableOnAndroid={false} keyboardShouldPersistTaps={Platform.OS === 'ios' ? false : true}>
                {/* <ScrollView style={styles.container}> */}
                <View style={styles.container}>
                    <View style={styles.banner}>
                        <Carousel
                            ref={(c) => { this._carousel = c; }}
                            data={imageSwiper}
                            renderItem={this._renderItem}
                            sliderWidth={WINDOW.width}
                            itemWidth={WINDOW.width}
                            itemHeight={200}
                            onSnapToItem={(index) => this.setState({ activeSlide: index })}
                        />
                        <View style={{ position: 'absolute', top: WINDOW.height * 0.03, left: WINDOW.width * 0.03 }}>
                            <TouchableOpacity onPress={() => Actions.pop()} style={{ height: WINDOW.height * 0.05, width: WINDOW.height * 0.1 }}>
                                <Image source={require('../Images/arrow-back.png')} style={{}} />
                            </TouchableOpacity>
                        </View>
                        <View style={styles.bannerText}>
                            <Text style={{ color: 'white', fontSize: WINDOW.height * 0.03, fontWeight: 'bold' }}>www.bridgetouganda.org</Text>
                        </View>
                        <View style={{ position: 'absolute', top: WINDOW.height * 0.15, left: WINDOW.width * 0.25 }}>
                            <Pagination
                                dotsLength={imageSwiper.length}
                                activeDotIndex={this.state.activeSlide}
                                containerStyle={{ backgroundColor: 'transparent' }}
                                dotStyle={{
                                    width: 10,
                                    height: 10,
                                    borderRadius: 5,
                                    marginHorizontal: 0,

                                }}
                                inactiveDotStyle={{

                                }}
                                inactiveDotColor='#f9934e'
                                dotColor='#f9934e'
                                inactiveDotScale={0.6}
                            />
                        </View>

                    </View>
                    <View style={styles.homeText}>
                        <Text style={{ color: "#efc352", fontSize: FONT_SIZE.SIZE_028, fontWeight: 'bold' }} >Building a Bridge to Uganda</Text>
                        <Text style={{ color: "#959595", fontSize: FONT_SIZE.SIZE_020, paddingVertical: '1%' }}>Channeling God's Love and Resources to Transform Lives</Text>
                    </View>
                    <View style={styles.formSection}>
                        <View style={{ flex: 0.85, paddingHorizontal: '7%', borderRadius: 5, backgroundColor: 'white' }}>
                            <View style={{ flex: 0.16, alignItems: "center", justifyContent: 'center', borderBottomColor: "#ddd", borderBottomWidth: 1.5, paddingVertical: "1%" }}>
                                <Text style={{ fontSize: WINDOW.height * 0.03, color: "#000000" }}>Postal Address   (Optional)</Text>
                            </View>
                            <View style={[styles.innerFormView, {}]}>
                                <FloatingLabel
                                    labelStyle={{ color: this.state.streetAddress1_Empty ? "#F60016" : this.state.streetAddress1_Clicked ? '#7dd89a' : '#ddd' }}
                                    inputStyle={styles.input}
                                    style={[styles.formInput, { borderBottomColor: this.state.streetAddress1_Clicked ? '#7dd89a' : "#ddd" }]}
                                    value={this.props.data ? this.props.data.streetAddress1 : this.state.streetAddress1}
                                    underlineColorAndroid={"transparent"}
                                    onBlur={() => this.setState({ streetAddress1_Clicked: false })}
                                    onFocus={() => this.setState({ streetAddress1_Clicked: true })}
                                    onChangeText={(streetAddress1) => { this.setState({ streetAddress1, streetAddress1_Empty: false }) }}
                                >Donor street address line 1</FloatingLabel>
                            </View>
                            <View style={[styles.innerFormView, {}]}>
                                <FloatingLabel
                                    labelStyle={{ color: this.state.streetAddress2_Clicked ? '#7dd89a' : '#ddd' }}
                                    inputStyle={styles.input}
                                    style={[styles.formInput, { borderBottomColor: this.state.streetAddress2_Clicked ? '#7dd89a' : "#ddd" }]}
                                    value={this.props.data ? this.props.data.streetAddress2 : this.state.streetAddress2}
                                    underlineColorAndroid={"transparent"}
                                    onBlur={() => this.setState({ streetAddress2_Clicked: false })}
                                    onFocus={() => this.setState({ streetAddress2_Clicked: true })}
                                    onChangeText={(streetAddress2) => { this.setState({ streetAddress2, }) }}
                                >Donor street address line 2</FloatingLabel>
                            </View>
                            <View style={[styles.innerFormView, {}]}>
                                <FloatingLabel
                                    labelStyle={{ color: this.state.city_Empty ? "#F60016" : this.state.city_Clicked ? '#7dd89a' : '#ddd' }}
                                    inputStyle={styles.input}
                                    style={[styles.formInput, { borderBottomColor: this.state.city_Clicked ? '#7dd89a' : "#ddd" }]}
                                    value={this.props.data ? this.props.data.city : this.state.city}
                                    underlineColorAndroid={"transparent"}
                                    onBlur={() => this.setState({ city_Clicked: false })}
                                    onFocus={() => this.setState({ city_Clicked: true })}
                                    onChangeText={(city) => { this.setState({ city, city_Empty: false }) }}
                                >Donor city</FloatingLabel>
                            </View>

                            <View style={{ flex: 0.13, backgroundColor: 'red' }}>
                                <Dropdown
                                    label='Select State'
                                    animationDuration={0}
                                    rippleDuration={0}
                                    value={this.props.states ? this.props.data.states : this.state.states}
                                    fontSize={WINDOW.height * 0.029}
                                    inputContainerStyle={{ borderBottomColor: 'transparent' }}
                                    data={arr}
                                    containerStyle={{ backgroundColor: 'white', height: WINDOW.height * 0.07, justifyContent: 'center', paddingBottom: '3%' }}
                                    onChangeText={(states) => { this.setState({ states }) }}
                                />
                            </View>

                            <View style={{ flex: 0.16 }}>
                                <FloatingLabel
                                    labelStyle={{ color: this.state.postalCode_Empty ? "#F60016" : this.state.postalCode_Clicked ? '#7dd89a' : '#ddd' }}
                                    inputStyle={styles.input}
                                    keyboardType='numeric'
                                    style={{ borderBottomColor: this.state.postalCode_Clicked ? '#7dd89a' : "#ddd" }}
                                    value={this.props.data ? this.props.data.postalCode : this.state.postalCode}
                                    underlineColorAndroid={"transparent"}
                                    onBlur={() => this.setState({ postalCode_Clicked: false })}
                                    onFocus={() => this.setState({ postalCode_Clicked: true })}
                                    onChangeText={(postalCode) => { this.setState({ postalCode, postalCode_Empty: false }) }}
                                > Donor postal Code</FloatingLabel>
                            </View>
                        </View>
                        <View style={[styles.PaymentButton, {}]}>
                            <TouchableOpacity onPress={() => { this.state.disable ? null : this.addPayment(datap), this.setState({ toggle: true }) }} style={{ backgroundColor: '#efc352', height: 45, marginTop: 10, borderWidth: 2, borderColor: '#efc352', justifyContent: 'center', alignItems: 'center' }}>
                                {!this.state.toggle ? <Text style={{ color: 'white', fontSize: 16, alignSelf: 'center', fontWeight: 'bold' }}>{this.state.disable ? 'Wait Initialising' : 'Add Payment'}</Text>
                                    :
                                    <ActivityIndicator />}
                            </TouchableOpacity>
                        </View>
                    </View>
                </View>
            </KeyboardAwareScrollView>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        height: WINDOW.height * 1
    },
    banner: {
        flex: 0.25,
        flexDirection: "row",
    },
    bannerText: {
        alignItems: 'center',
        justifyContent: 'center',
        position: 'absolute',
        top: WINDOW.height * 0.08,
        right: WINDOW.width * 0.2,
    },
    homeText: {
        flex: 0.09,
        padding: '3%',
        backgroundColor: "white"
    },
    formSection: {
        flex: 0.65,
        padding: '3%',
        shadowOpacity: 0.2,
        shadowOffset: { width: 3, height: 3 },
        shadowColor: 'grey',
        elevation: 5
    },
    formInput: {
        borderWidth: 0,
        borderBottomWidth: 1.5,
        color: "#959595",
        flex: 1
    },
    input: {
        borderWidth: 0,
        color: "#959595",
        fontSize: WINDOW.height * 0.03,
    },
    innerFormView: {
        flex: .1667
    },
    PaymentButton: {
        flex: .15,
    },
});

export default Address;